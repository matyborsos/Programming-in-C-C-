#include <iostream>
#include <cstdlib>
#include <ctime> 
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"


/*
	   DIAGRAM OF CLASS RELATIONS
	   
	   				AREA
					|  |
				    |  |
			   CIRCLE RECTANGLE
			   	  |		  |
				  |		  |
				RING	SQUARE


*/


/*
	Explanations for numbered points:
	(1) -> The program creates an array of num_obj Area type pointers
	(2) -> The integer index used for looping through the 
	       list at (7) is initialized with 0
	(3) -> The double sum_area that holds the sum of all the areas
		   is initialized with 0.0
	(4) -> In the following lines up until (5) a creation of a
		   new instance is declared and cojnstructed,
		   while also a message is printed onto stdout about the 
		   creation of that instance
	(5) -> In the following lines assign the addresses of the instances 
		   created before (5) to the elements of the array of Area type pointers
	(7) -> A while loop that goes through the array of Area type pointers
	(8) -> The program assigns the return value of calcArea method 
	       that is called on the current instance which is referred to 
		   by the address found on the current index of the array of Area type 
		   pointers, then it is incremented by 1 and add value of 
		   area to sum_area
	(9) -> The value of sum_area (the sum of all the areas of the instances
		   created before) is printed into stdout using cout  
*/


const int num_obj = 7;
int main() {
	Area *list[num_obj];						// (1)
	int index = 0;								// (2)
	double sum_area = 0.0;						// (3)
	double sum_perimeter = 0.0;

    cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// (4)
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
	cout << "Creating Square: ";
	Square lila_square("LILA", 10);

	list[0] = &blue_ring;						// (5)
	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
	list[6] = &lila_square;

	while (index < num_obj) {					// (7)
		(list[index])->getColor();				
		double area = list[index++]->calcArea();// (8)
		sum_area += area;
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	// (9)

	index = 0;
	while (index < num_obj) {					
		(list[index])->getColor();				
		double perimeter = list[index++]->calcPerimeter();
		sum_perimeter += perimeter;
	}
	cout << "\nThe total perimeter is "
			<< sum_perimeter << " units " << endl;	
	return 0;

}
